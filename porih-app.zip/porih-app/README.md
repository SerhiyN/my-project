# Поріг — каркас застосунку (React Native / Expo)

Робочий код, який запускається локально й симулятором показує мапу, картки оголошень, форму «Здати житло» і чат. Поки `.env` не заповнений — застосунок автоматично працює на мокових даних із `src/data/mockListings.js`, тож можна розробляти й бачити результат до підключення Firebase.

## 1. Встановлення

```bash
npm install -g expo-cli eas-cli   # якщо ще не стоїть
npm install
cp .env.example .env              # і заповніть значення (крок 2 і 3)
npx expo start
```

Відскануйте QR-код застосунком **Expo Go** на телефоні, або натисніть `i` / `a` у терміналі для симулятора iOS / емулятора Android.

## 2. Google Maps API ключ

1. console.cloud.google.com → створіть проєкт
2. Увімкніть **Maps SDK for iOS** і **Maps SDK for Android**
3. Credentials → Create credentials → API key
4. Створіть два окремі ключі (по одному на платформу) й обмежте кожен відповідним бандл-айді / package name з `app.json`
5. Вставте ключі в `.env` і в `app.json` (`ios.config.googleMapsApiKey`, `android.config.googleMaps.apiKey`)

Безкоштовного місячного кредиту Google зазвичай вистачає на розробку та невеликий запуск; за реальних обсягів — оплата за використання.

## 3. Firebase

1. console.firebase.google.com → Create project
2. Build → Firestore Database → Create database (почніть у test mode, потім налаштуйте правила безпеки)
3. Build → Authentication → увімкніть Phone (або Email/Password для першої версії — простіше)
4. Project settings → General → Your apps → Add app (Web) → скопіюйте конфіг у `.env`

## 4. Структура проєкту

```
App.js                      точка входу
src/
  theme.js                  кольори/шрифти, ідентичні веб-прототипу
  config/firebase.js        ініціалізація Firebase
  navigation/RootNavigator.js
  screens/                  Map, ListingDetail, CreateListing, Chat, Profile
  components/               ListingMarker, TagBadge
  services/                 listingsService (Firestore), authService
  data/mockListings.js      тестові дані на час розробки
```

## 5. Що ще варто додати перед закритою бетою

- Реальна авторизація (зараз `ownerId` у `CreateListingScreen` — заглушка `"demo-user"`)
- Завантаження фото (Firebase Storage + `expo-image-picker`)
- Правила безпеки Firestore (зараз база відкрита в test mode — це **не** для продакшну)
- Push-сповіщення про нові повідомлення (Firebase Cloud Messaging)
- Сторінка видалення акаунта в самому застосунку (Apple вимагає це для схвалення)

## 6. Збірка та публікація

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform ios
eas build --platform android
```

Далі:
- **iOS**: `eas submit --platform ios` (потрібен Apple Developer акаунт, $99/рік) → App Store Connect → заповнити Privacy Nutrition Label, скриншоти, для маркетплейсу — підготувати демо-акаунт для рев'юера
- **Android**: `eas submit --platform android` (потрібен Google Play Console акаунт, $25 одноразово) → пройти обов'язкове закрите тестування (12+ тестувальників, 14–20 днів для нових акаунтів) перед публічним релізом

Детальніше про юридичні моменти, монетизацію і повний план — дивіться `porih-roadmap.md`.
