// Тестові дані для розробки без підключеного Firebase.
// Структура повторює схему документів у Firestore-колекції "listings".

export const CITIES = [
  { id: "kyiv", name: "Київ", lat: 50.4501, lng: 30.5234 },
  { id: "lisbon", name: "Лісабон", lat: 38.7223, lng: -9.1393 },
  { id: "tbilisi", name: "Тбілісі", lat: 41.7151, lng: 44.8271 },
  { id: "bali", name: "Балі", lat: -8.4095, lng: 115.1889 },
];

export const MOCK_LISTINGS = [
  {
    id: "kv1",
    cityId: "kyiv",
    lat: 50.4601,
    lng: 30.5134,
    title: "Мансарда з видом на Дніпро",
    area: "Поділ",
    price: 38,
    rating: 4.9,
    reviews: 61,
    views: 412,
    host: { id: "h1", name: "Олена", verified: true },
    photos: [],
    tags: ["wifi", "kitchen"],
  },
  {
    id: "kv2",
    cityId: "kyiv",
    lat: 50.4321,
    lng: 30.5512,
    title: "Студія біля Софіївської",
    area: "Печерськ",
    price: 52,
    rating: 4.7,
    reviews: 33,
    views: 188,
    host: { id: "h2", name: "Андрій", verified: true },
    photos: [],
    tags: ["wifi", "view"],
  },
  {
    id: "ls1",
    cityId: "lisbon",
    lat: 38.7139,
    lng: -9.1334,
    title: "Тераса в Алфамі з видом на річку",
    area: "Alfama",
    price: 61,
    rating: 5.0,
    reviews: 88,
    views: 540,
    host: { id: "h3", name: "Pedro", verified: true },
    photos: [],
    tags: ["view", "wifi"],
  },
];

export default MOCK_LISTINGS;
