// Ті самі токени, що й у веб-прототипі (porih-prototype.jsx) — щоб застосунок
// виглядав ідентично після переходу з дизайн-демо на реальний код.

export const colors = {
  ink: "#14171C",
  paper: "#ECE6D8",
  paperDeep: "#DDD3B8",
  brass: "#C98A3B",
  brassDark: "#A66B26",
  teal: "#1F5C57",
  cream: "#F5F0E3",
  text: "#1B1B16",
  muted: "#7A7464",
};

export const fonts = {
  display: "Fraunces_600SemiBold",
  body: "System",
};

export const radius = {
  sm: 8,
  md: 14,
  lg: 24,
  full: 999,
};

export default { colors, fonts, radius };
