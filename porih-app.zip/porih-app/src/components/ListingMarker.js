import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Marker } from "react-native-maps";
import { colors } from "../theme";

// Кругла "штамп"-мітка з ціною замість стандартної краплі Google Maps —
// той самий візуальний прийом, що й у веб-прототипі.
export default function ListingMarker({ listing, selected, onPress }) {
  return (
    <Marker
      coordinate={{ latitude: listing.lat, longitude: listing.lng }}
      onPress={onPress}
      tracksViewChanges={false}
    >
      <View style={[styles.bubble, selected && styles.bubbleSelected]}>
        <Text style={styles.price}>${listing.price}</Text>
      </View>
      <View style={[styles.tail, selected && styles.tailSelected]} />
    </Marker>
  );
}

const styles = StyleSheet.create({
  bubble: {
    backgroundColor: colors.brass,
    borderColor: colors.cream,
    borderWidth: 2,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
    alignSelf: "center",
  },
  bubbleSelected: {
    backgroundColor: colors.teal,
  },
  price: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 12,
  },
  tail: {
    alignSelf: "center",
    width: 0,
    height: 0,
    borderLeftWidth: 6,
    borderRightWidth: 6,
    borderTopWidth: 7,
    borderLeftColor: "transparent",
    borderRightColor: "transparent",
    borderTopColor: colors.brass,
  },
  tailSelected: {
    borderTopColor: colors.teal,
  },
});
