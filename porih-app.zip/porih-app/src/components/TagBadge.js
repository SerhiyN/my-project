import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors } from "../theme";

const ICON = { wifi: "wifi", kitchen: "cafe", view: "image", pool: "water", parking: "car" };
const LABEL = { wifi: "Wi-Fi", kitchen: "Кухня", view: "Краєвид", pool: "Басейн", parking: "Паркінг" };

export default function TagBadge({ tag }) {
  return (
    <View style={styles.badge}>
      <Ionicons name={ICON[tag] || "pricetag"} size={12} color={colors.text} />
      <Text style={styles.label}>{LABEL[tag] || tag}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: colors.paperDeep,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
  },
  label: { fontSize: 11, color: colors.text },
});
