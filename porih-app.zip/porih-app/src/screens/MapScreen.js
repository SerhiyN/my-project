import React, { useState, useEffect, useRef } from "react";
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, ActivityIndicator,
} from "react-native";
import MapView from "react-native-maps";
import { Ionicons } from "@expo/vector-icons";
import ListingMarker from "../components/ListingMarker";
import { colors, radius } from "../theme";
import { CITIES } from "../data/mockListings";
import { subscribeToCityListings } from "../services/listingsService";

export default function MapScreen({ navigation }) {
  const [cityId, setCityId] = useState("kyiv");
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState(null);
  const mapRef = useRef(null);
  const city = CITIES.find((c) => c.id === cityId);

  useEffect(() => {
    setLoading(true);
    const unsubscribe = subscribeToCityListings(cityId, (data) => {
      setListings(data);
      setLoading(false);
    });
    mapRef.current?.animateToRegion({
      latitude: city.lat, longitude: city.lng, latitudeDelta: 0.08, longitudeDelta: 0.08,
    }, 400);
    return unsubscribe;
  }, [cityId]);

  return (
    <View style={styles.container}>
      <View style={styles.topBar}>
        <View style={styles.searchRow}>
          <View style={styles.searchPill}>
            <Ionicons name="search" size={16} color={colors.text} />
            <Text style={styles.searchText}>{city.name}</Text>
          </View>
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => navigation.navigate("CreateListing", { cityId })}
          >
            <Ionicons name="add" size={20} color="#fff" />
          </TouchableOpacity>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabsRow}>
          {CITIES.map((c) => (
            <TouchableOpacity
              key={c.id}
              onPress={() => { setCityId(c.id); setSelectedId(null); }}
              style={[styles.tab, c.id === cityId && styles.tabActive]}
            >
              <Text style={[styles.tabText, c.id === cityId && styles.tabTextActive]}>{c.name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <MapView
        ref={mapRef}
        style={styles.map}
        initialRegion={{ latitude: city.lat, longitude: city.lng, latitudeDelta: 0.08, longitudeDelta: 0.08 }}
      >
        {listings.map((l) => (
          <ListingMarker
            key={l.id}
            listing={l}
            selected={selectedId === l.id}
            onPress={() => {
              setSelectedId(l.id);
              navigation.navigate("ListingDetail", { listing: l });
            }}
          />
        ))}
      </MapView>

      {loading && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator color={colors.brassDark} />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.paper },
  map: { flex: 1 },
  topBar: { backgroundColor: colors.cream, paddingTop: 54, paddingBottom: 10, paddingHorizontal: 16, zIndex: 10 },
  searchRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  searchPill: {
    flex: 1, flexDirection: "row", alignItems: "center", gap: 8,
    backgroundColor: colors.paperDeep, borderRadius: radius.full, paddingHorizontal: 14, paddingVertical: 10,
  },
  searchText: { color: colors.text, opacity: 0.7 },
  addButton: { backgroundColor: colors.teal, borderRadius: radius.full, width: 38, height: 38, alignItems: "center", justifyContent: "center" },
  tabsRow: { marginTop: 10 },
  tab: { borderWidth: 2, borderColor: "#C9C0A8", borderRadius: radius.full, paddingHorizontal: 12, paddingVertical: 5, marginRight: 8 },
  tabActive: { borderColor: colors.brassDark, backgroundColor: "#F0E3CC" },
  tabText: { fontSize: 12, fontWeight: "600", color: colors.text },
  tabTextActive: { color: colors.brassDark },
  loadingOverlay: { position: "absolute", top: 140, alignSelf: "center" },
});
