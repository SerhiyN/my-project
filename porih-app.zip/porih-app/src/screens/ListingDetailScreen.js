import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import TagBadge from "../components/TagBadge";
import { colors, radius } from "../theme";

export default function ListingDetailScreen({ route, navigation }) {
  const { listing } = route.params;

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20 }}>
      <View style={styles.headerRow}>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>{listing.title}</Text>
          <Text style={styles.subtitle}>{listing.area}</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="close" size={22} color={colors.text} />
        </TouchableOpacity>
      </View>

      <View style={styles.photoPlaceholder}>
        <Ionicons name="camera-outline" size={18} color={colors.muted} />
        <Text style={styles.photoText}>{listing.photos?.length || 0} фото</Text>
      </View>

      <View style={styles.metaRow}>
        <Text style={styles.price}>${listing.price}<Text style={styles.priceUnit}> /ніч</Text></Text>
        {listing.rating ? (
          <View style={styles.ratingRow}>
            <Ionicons name="star" size={14} color={colors.brassDark} />
            <Text style={styles.ratingText}>{listing.rating} ({listing.reviews})</Text>
          </View>
        ) : (
          <Text style={styles.newBadge}>нове оголошення</Text>
        )}
        <View style={styles.ratingRow}>
          <Ionicons name="eye-outline" size={14} color={colors.muted} />
          <Text style={styles.viewsText}>{listing.views || 0}</Text>
        </View>
      </View>

      {listing.tags?.length > 0 && (
        <View style={styles.tagsRow}>
          {listing.tags.map((t) => <TagBadge key={t} tag={t} />)}
        </View>
      )}

      <View style={styles.hostRow}>
        <View style={styles.hostAvatar}>
          <Text style={styles.hostInitial}>{listing.host?.name?.[0] || "?"}</Text>
        </View>
        <Text style={styles.hostName}>{listing.host?.name}</Text>
        {listing.host?.verified && <Ionicons name="checkmark-circle" size={16} color={colors.teal} />}
      </View>

      <TouchableOpacity
        style={styles.contactButton}
        onPress={() => navigation.navigate("Chat", { listing })}
      >
        <Ionicons name="chatbubble-ellipses-outline" size={16} color="#fff" />
        <Text style={styles.contactText}>Написати напряму</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.cream },
  headerRow: { flexDirection: "row", alignItems: "flex-start" },
  title: { fontSize: 20, fontWeight: "700", color: colors.text },
  subtitle: { color: colors.muted, marginTop: 2, fontSize: 13 },
  photoPlaceholder: {
    height: 140, backgroundColor: colors.paperDeep, borderRadius: radius.md,
    marginTop: 14, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 6,
  },
  photoText: { color: colors.muted, fontSize: 12 },
  metaRow: { flexDirection: "row", alignItems: "center", gap: 16, marginTop: 14 },
  price: { fontSize: 16, fontWeight: "700", color: colors.text },
  priceUnit: { fontSize: 12, fontWeight: "400", opacity: 0.6 },
  ratingRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  ratingText: { fontSize: 13, color: colors.text },
  viewsText: { fontSize: 12, color: colors.muted },
  newBadge: { color: colors.teal, fontSize: 12, fontWeight: "600" },
  tagsRow: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 14 },
  hostRow: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 20 },
  hostAvatar: { width: 32, height: 32, borderRadius: 16, backgroundColor: colors.brass, alignItems: "center", justifyContent: "center" },
  hostInitial: { color: "#fff", fontWeight: "700", fontSize: 13 },
  hostName: { color: colors.text, fontSize: 14 },
  contactButton: {
    marginTop: 20, backgroundColor: colors.teal, borderRadius: radius.md, paddingVertical: 14,
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
  },
  contactText: { color: "#fff", fontWeight: "700", fontSize: 14 },
});
