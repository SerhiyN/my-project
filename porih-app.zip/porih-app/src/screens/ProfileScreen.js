import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius } from "../theme";

// Заглушка профілю. Підключіть authService.listenToAuthState, щоб показувати
// реальні дані користувача, статус верифікації і список власних оголошень.
export default function ProfileScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.avatar}>
        <Ionicons name="person" size={28} color="#fff" />
      </View>
      <Text style={styles.name}>Гість</Text>
      <Text style={styles.status}>Акаунт не верифіковано</Text>

      <TouchableOpacity style={styles.primaryButton}>
        <Ionicons name="shield-checkmark-outline" size={16} color="#fff" />
        <Text style={styles.primaryButtonText}>Пройти верифікацію</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.secondaryButton}>
        <Text style={styles.secondaryButtonText}>Мої оголошення</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.cream, alignItems: "center", paddingTop: 80, paddingHorizontal: 24 },
  avatar: { width: 72, height: 72, borderRadius: 36, backgroundColor: colors.brass, alignItems: "center", justifyContent: "center" },
  name: { fontSize: 18, fontWeight: "700", color: colors.text, marginTop: 12 },
  status: { fontSize: 13, color: colors.muted, marginTop: 4 },
  primaryButton: {
    flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.teal,
    borderRadius: radius.md, paddingVertical: 12, paddingHorizontal: 20, marginTop: 24, width: "100%", justifyContent: "center",
  },
  primaryButtonText: { color: "#fff", fontWeight: "700" },
  secondaryButton: { marginTop: 12, paddingVertical: 12, width: "100%", alignItems: "center" },
  secondaryButtonText: { color: colors.text, fontWeight: "600" },
});
