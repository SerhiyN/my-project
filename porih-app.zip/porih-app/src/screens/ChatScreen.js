import React, { useState } from "react";
import { View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius } from "../theme";

// Спрощений чат для MVP. Для продакшну замініть локальний useState на
// Firestore-колекцію "messages" з onSnapshot (за зразком listingsService.js)
// або підключіть готовий SDK (Stream / Sendbird), якщо потрібен масштаб.
export default function ChatScreen({ route }) {
  const { listing } = route.params;
  const [messages, setMessages] = useState([
    { id: "m0", fromMe: false, text: `Вітаю! Запитуйте, що цікавить щодо «${listing.title}».` },
  ]);
  const [text, setText] = useState("");

  function send() {
    if (!text.trim()) return;
    setMessages((prev) => [...prev, { id: String(Date.now()), fromMe: true, text }]);
    setText("");
  }

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <Text style={styles.header}>Чат з {listing.host?.name || "господарем"}</Text>
      <FlatList
        data={messages}
        keyExtractor={(m) => m.id}
        contentContainerStyle={{ padding: 16, gap: 8 }}
        renderItem={({ item }) => (
          <View style={[styles.bubble, item.fromMe ? styles.bubbleMe : styles.bubbleThem]}>
            <Text style={item.fromMe ? styles.bubbleTextMe : styles.bubbleTextThem}>{item.text}</Text>
          </View>
        )}
      />
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          placeholder="Повідомлення..."
          value={text}
          onChangeText={setText}
        />
        <TouchableOpacity style={styles.sendButton} onPress={send}>
          <Ionicons name="send" size={16} color="#fff" />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.cream },
  header: { paddingTop: 54, paddingHorizontal: 16, paddingBottom: 8, fontWeight: "700", fontSize: 16, color: colors.text },
  bubble: { maxWidth: "80%", padding: 10, borderRadius: radius.sm },
  bubbleMe: { backgroundColor: colors.teal, alignSelf: "flex-end" },
  bubbleThem: { backgroundColor: colors.paperDeep, alignSelf: "flex-start" },
  bubbleTextMe: { color: "#fff", fontSize: 14 },
  bubbleTextThem: { color: colors.text, fontSize: 14 },
  inputRow: { flexDirection: "row", padding: 12, gap: 8, borderTopWidth: 1, borderTopColor: colors.paperDeep },
  input: { flex: 1, backgroundColor: colors.paperDeep, borderRadius: radius.full, paddingHorizontal: 14, paddingVertical: 10, color: colors.text },
  sendButton: { backgroundColor: colors.teal, borderRadius: radius.full, width: 40, height: 40, alignItems: "center", justifyContent: "center" },
});
