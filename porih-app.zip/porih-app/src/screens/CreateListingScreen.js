import React, { useState } from "react";
import {
  View, Text, TextInput, StyleSheet, TouchableOpacity, ActivityIndicator, Alert,
} from "react-native";
import MapView, { Marker } from "react-native-maps";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius } from "../theme";
import { CITIES } from "../data/mockListings";
import { createListing } from "../services/listingsService";

export default function CreateListingScreen({ route, navigation }) {
  const { cityId } = route.params;
  const city = CITIES.find((c) => c.id === cityId);
  const [point, setPoint] = useState(null);
  const [title, setTitle] = useState("");
  const [area, setArea] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);

  async function handleSubmit() {
    if (!point || !title || !price) {
      Alert.alert("Заповніть поля", "Вкажіть точку на мапі, назву й ціну");
      return;
    }
    setSaving(true);
    try {
      // ownerId тут — заглушка; підставте auth.currentUser.uid після підключення авторизації
      await createListing({
        cityId, lat: point.latitude, lng: point.longitude,
        title, area, price, description, ownerId: "demo-user",
      });
      Alert.alert("Готово", "Оголошення опубліковано");
      navigation.goBack();
    } catch (err) {
      Alert.alert("Помилка", err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Здати житло — {city.name}</Text>
      </View>

      <Text style={styles.hint}>Торкніться мапи, щоб позначити, де знаходиться житло</Text>

      <MapView
        style={styles.map}
        initialRegion={{ latitude: city.lat, longitude: city.lng, latitudeDelta: 0.08, longitudeDelta: 0.08 }}
        onPress={(e) => setPoint(e.nativeEvent.coordinate)}
      >
        {point && <Marker coordinate={point} pinColor={colors.teal} />}
      </MapView>

      <View style={styles.form}>
        <TextInput style={styles.input} placeholder="Назва оголошення" value={title} onChangeText={setTitle} />
        <TextInput style={styles.input} placeholder="Район" value={area} onChangeText={setArea} />
        <TextInput style={styles.input} placeholder="Ціна за ніч, $" value={price} onChangeText={setPrice} keyboardType="numeric" />
        <TextInput
          style={[styles.input, styles.textarea]}
          placeholder="Короткий опис"
          value={description}
          onChangeText={setDescription}
          multiline
        />

        <TouchableOpacity style={styles.submit} onPress={handleSubmit} disabled={saving}>
          {saving ? <ActivityIndicator color="#fff" /> : (
            <>
              <Ionicons name="checkmark" size={16} color="#fff" />
              <Text style={styles.submitText}>Опублікувати</Text>
            </>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.cream },
  header: { flexDirection: "row", alignItems: "center", gap: 10, paddingTop: 54, paddingHorizontal: 16, paddingBottom: 8 },
  headerTitle: { fontSize: 17, fontWeight: "700", color: colors.text },
  hint: { fontSize: 12, color: colors.muted, paddingHorizontal: 16, paddingBottom: 8 },
  map: { height: 220 },
  form: { padding: 16, gap: 10 },
  input: { backgroundColor: colors.paperDeep, borderRadius: radius.sm, paddingHorizontal: 12, paddingVertical: 12, fontSize: 14, color: colors.text },
  textarea: { height: 80, textAlignVertical: "top" },
  submit: {
    backgroundColor: colors.brassDark, borderRadius: radius.md, paddingVertical: 14,
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 6,
  },
  submitText: { color: "#fff", fontWeight: "700", fontSize: 14 },
});
