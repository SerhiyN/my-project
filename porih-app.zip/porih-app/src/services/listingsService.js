// Шар роботи з оголошеннями. Поки Firebase не підключений (немає .env),
// функції падають назад на мокові дані — це дозволяє розробляти екрани
// без живого бекенду, а потім просто заповнити .env і нічого не міняти в UI.
import {
  collection, addDoc, query, where, getDocs, onSnapshot, serverTimestamp,
} from "firebase/firestore";
import { db } from "../config/firebase";
import { MOCK_LISTINGS } from "../data/mockListings";

const LISTINGS = "listings";

// Простий bounding-box запит: для MVP цього достатньо, для масштабування
// варто перейти на geohash (наприклад через бібліотеку geofire-common).
export async function getListingsForCity(cityId) {
  try {
    const q = query(collection(db, LISTINGS), where("cityId", "==", cityId));
    const snap = await getDocs(q);
    if (snap.empty) return MOCK_LISTINGS.filter((l) => l.cityId === cityId);
    return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  } catch (err) {
    console.warn("Firestore недоступний, використовую мокові дані:", err.message);
    return MOCK_LISTINGS.filter((l) => l.cityId === cityId);
  }
}

export function subscribeToCityListings(cityId, onChange) {
  try {
    const q = query(collection(db, LISTINGS), where("cityId", "==", cityId));
    return onSnapshot(q, (snap) => {
      onChange(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
  } catch (err) {
    onChange(MOCK_LISTINGS.filter((l) => l.cityId === cityId));
    return () => {};
  }
}

export async function createListing({ cityId, lat, lng, title, area, price, description, ownerId }) {
  const doc = {
    cityId, lat, lng, title, area,
    price: Number(price) || 0,
    description: description || "",
    ownerId,
    photos: [],
    tags: [],
    rating: null,
    reviews: 0,
    views: 0,
    createdAt: serverTimestamp(),
  };
  const ref = await addDoc(collection(db, LISTINGS), doc);
  return { id: ref.id, ...doc };
}
