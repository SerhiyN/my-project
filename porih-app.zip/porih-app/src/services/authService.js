// Авторизація за номером телефону. На реальному проєкті Firebase Phone Auth
// в Expo вимагає либо EAS Build з нативним модулем, либо recaptcha-flow для вебу.
// Для MVP найпростіший шлях — підключити стороннього провайдера (напр. Firebase
// Phone Auth через expo-firebase-recaptcha) і повернути сюди реальну реалізацію.
import { signInWithPhoneNumber, onAuthStateChanged } from "firebase/auth";
import { auth } from "../config/firebase";

export function listenToAuthState(callback) {
  return onAuthStateChanged(auth, callback);
}

export async function sendVerificationCode(phoneNumber, recaptchaVerifier) {
  return signInWithPhoneNumber(auth, phoneNumber, recaptchaVerifier);
}

export async function confirmCode(confirmationResult, code) {
  return confirmationResult.confirm(code);
}
